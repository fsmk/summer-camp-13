print("helloworld \n python")
print(1, 3)
print(1 * 4)
