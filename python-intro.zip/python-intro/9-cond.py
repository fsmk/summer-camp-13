#! -*- coding: utf-8 -*-

print(True and True)
print(True and False)
print(True or False)
print(False or True)
print(1 and 2)
