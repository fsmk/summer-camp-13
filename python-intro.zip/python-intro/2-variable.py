#! /usr/bin/env python
#! -*- coding: utf-8 -*-

# Variable
"""
This
is multline
comment
"""
a = 1
print(a)
name = "kracekumar"
print(name)
a = 3
name = "python"
print a, name
print(a, name)
