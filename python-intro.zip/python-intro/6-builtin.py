#! -*- coding: utf-8 -*-

print("Max of 2, 3")
print(max(2, 3))
print("Minimum of 2, 3")
print(min(2, 3))
print("Find length of a string")
print(len("python"))
#print(len(2))
print(str(23))
print(type(str(23)))
print(int("23"))
print(type(int("23")))
