#! -*- coding: utf-8 -*-

desc = "About Me"
about_me = """
I am kracekumar.
I work as Programmer at HasGeek.
I contribute to Free Open Source Software.
"""
print(desc)
print(about_me)
