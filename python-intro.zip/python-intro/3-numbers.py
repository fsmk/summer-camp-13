#! -*- coding: utf-8 -*-

# Numbers
a = 23
b = 23
print("Addition")
print(a + b)

print("Multiplication")
a = 23 * 45.0
print(a)

# Divide 2/3
print("Division")
print(2/3)
print(2/3.0)
print("Modulo")
print(2 % 3)
print(3 % 2)
# More operators
print("More operators")
print(2 + 3 * 4)
name = "krace"
name = """
this
is 
multiline string
"""
exp = """
1 + 2 + 3 * 4 + 5
  ↓
  3   + 3 * 4 + 5
          ↓
  3   +   12  + 5
      ↓
      15      + 5
              ↓
             20
 """
print(exp)
print(1 + 2 + 3 * 4 + 5)
