#! -*- coding: utf-8 -*-

print(1, 3)
print("Hello Python")
