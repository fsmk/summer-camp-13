#! -*- coding: utf-8 -*-

lang = "python"
print(lang.upper())
# temp = lang.upper()
# print(temp.lower())
print(lang.upper().lower())
