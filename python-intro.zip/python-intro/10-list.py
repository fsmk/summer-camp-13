#! -*- coding: utf-8 -*-

languages = ["Python", "C", "Go", "lua", "JavaScript"]
print("first element")
print(languages[0])
print("total elements")
print(len(languages))
print("Last element")
print(languages[len(languages) - 1])
print(languages[-1])
print(languages[-2])
#print(languages[23])

details = [23, "Banaglore", "Kracekumar", True]
print("Heterogenous elements")
print(details[0])
print(details[-1])
print(details[1])
print(details)
